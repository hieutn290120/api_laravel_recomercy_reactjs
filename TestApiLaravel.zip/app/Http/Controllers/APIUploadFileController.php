<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class APIUploadFileController extends Controller
{
    //
    public function uploadfile(){
        
    }
}
